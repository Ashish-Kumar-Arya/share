package com.bej.usermovieservice.exception;

public class UserAlreadyExistsException extends Exception {
}
