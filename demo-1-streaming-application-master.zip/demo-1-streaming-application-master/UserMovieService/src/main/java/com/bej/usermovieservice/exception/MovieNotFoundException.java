package com.bej.usermovieservice.exception;

public class MovieNotFoundException extends Throwable {
}
