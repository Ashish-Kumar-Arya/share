package com.bej.usermovieservice.exception;

public class UserNotFoundException extends Throwable {
}
